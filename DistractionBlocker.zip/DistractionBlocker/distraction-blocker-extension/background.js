const USER_ID = "12345";
const API_URL = `http://localhost:5000/api/blocklist/${USER_ID}`;

console.log("🟢 Extension loaded");

async function syncBlockedSites() {
  console.log("🔄 Syncing blocklist...");
  try {
    const res = await fetch(API_URL);
    const blockedSites = await res.json();
    console.log("📋 Fetched blocklist:", blockedSites);
    
    if (!blockedSites || blockedSites.length === 0) {
      console.warn("⚠️ No sites to block!");
      // Clear all rules if no sites
      const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
      const existingIds = existingRules.map(r => r.id);
      await chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: existingIds,
        addRules: []
      });
      return;
    }

    const rules = blockedSites.map((site, index) => ({
      id: index + 1,
      priority: 1,
      action: { 
        type: "redirect",
        redirect: { 
          url: `chrome-extension://${chrome.runtime.id}/focus.html?site=${encodeURIComponent(site)}`
        }
      },
      condition: { 
        urlFilter: `||${site}^`, 
        resourceTypes: ["main_frame"] 
      }
    }));

    const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
    const existingIds = existingRules.map(r => r.id);
    
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: existingIds,
      addRules: rules
    });
    
    console.log("✅ Rules updated:", rules);
    
  } catch (err) {
    console.error("❌ Failed to sync blocked sites:", err);
  }
}

// Listen for sync requests from focus.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'syncBlocklist') {
    console.log('📨 Received sync request');
    syncBlockedSites().then(() => {
      sendResponse({ success: true });
    });
    return true; // Keep the message channel open for async response
  }
});

// Initial sync
syncBlockedSites();

// Sync every minute
setInterval(syncBlockedSites, 60000);

chrome.runtime.onStartup.addListener(syncBlockedSites);