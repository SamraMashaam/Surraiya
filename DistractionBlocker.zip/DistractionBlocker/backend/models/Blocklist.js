const mongoose = require("mongoose");

const blocklistSchema = new mongoose.Schema({
  userId: { type: String, required: true, unique: true },
  sites: [String]
});

module.exports = mongoose.model("Blocklist", blocklistSchema);