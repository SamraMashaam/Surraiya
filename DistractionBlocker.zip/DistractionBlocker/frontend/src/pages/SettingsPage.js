import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function SettingsPage() {
  const [blockedSites, setBlockedSites] = useState([]);
  const [newSite, setNewSite] = useState("");
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const USER_ID = "12345";
  const API_URL = `http://localhost:5000/api/blocklist/${USER_ID}`;

  useEffect(() => {
    fetchBlockedSites();
  }, []);

  const fetchBlockedSites = async () => {
    setLoading(true);
    try {
      const res = await fetch(API_URL);
      const data = await res.json();
      setBlockedSites(data);
    } catch (err) {
      console.error("Failed to fetch blocked sites:", err);
      setError("Failed to load blocked sites. Make sure your backend is running.");
    }
    setLoading(false);
  };

  const triggerExtensionSync = () => {
    setSyncing(true);
    setTimeout(() => {
      setSyncing(false);
    }, 1000);
  };

  const validateAndCleanSite = (input) => {
    if (!input || typeof input !== 'string') {
      return { valid: false, error: "Please enter a website" };
    }

    // Clean up the input
    let site = input.trim().toLowerCase();
    
    // Remove protocol (http://, https://)
    site = site.replace(/^(https?:\/\/)/, '');
    
    // Remove www.
    site = site.replace(/^www\./, '');
    
    // Remove trailing slash and any path/query
    site = site.split('/')[0];
    site = site.split('?')[0];
    
    // Remove port numbers if any
    site = site.split(':')[0];
    
    if (!site) {
      return { valid: false, error: "Please enter a valid website" };
    }

    // Check for valid domain format
    const domainPattern = /^[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,}$/;
    if (!domainPattern.test(site)) {
      return { 
        valid: false, 
        error: "Invalid domain format. Use format: example.com" 
      };
    }

    // Check for localhost/IP addresses
    if (site.includes('localhost') || site.match(/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/)) {
      return { 
        valid: false, 
        error: "Cannot block localhost or IP addresses" 
      };
    }

    // Check minimum length
    if (site.length < 4) {
      return { 
        valid: false, 
        error: "Domain name too short" 
      };
    }

    // Check if already blocked
    if (blockedSites.includes(site)) {
      return { 
        valid: false, 
        error: `${site} is already in your blocklist` 
      };
    }

    return { valid: true, site };
  };

  const addSite = async (e) => {
    e.preventDefault();
    setError("");

    const validation = validateAndCleanSite(newSite);
    
    if (!validation.valid) {
      setError(validation.error);
      return;
    }

    const site = validation.site;
    setLoading(true);

    try {
      const res = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ site })
      });

      if (res.ok) {
        setNewSite("");
        setError("");
        await fetchBlockedSites();
        triggerExtensionSync();
      } else {
        const errorData = await res.json();
        setError(errorData.error || "Failed to add site");
      }
    } catch (err) {
      console.error("Failed to add site:", err);
      setError("Failed to add site. Make sure your backend is running.");
    }
    setLoading(false);
  };

  const removeSite = async (site) => {
    if (!confirm(`Remove ${site} from your blocklist?`)) return;

    try {
      const res = await fetch(`${API_URL}/${encodeURIComponent(site)}`, {
        method: "DELETE"
      });

      if (res.ok) {
        await fetchBlockedSites();
        triggerExtensionSync();
      } else {
        setError("Failed to remove site");
      }
    } catch (err) {
      console.error("Failed to remove site:", err);
      setError("Failed to remove site. Make sure your backend is running.");
    }
  };

  const handleInputChange = (e) => {
    setNewSite(e.target.value);
    setError(""); // Clear error when user starts typing
  };

  return (
    <div style={{
      minHeight: "100vh",
      padding: "40px 20px"
    }}>
      <div style={{
        maxWidth: "800px",
        margin: "0 auto",
        padding: "40px",
        borderRadius: "10px",
      }}>
        <div style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginBottom: "30px",
          flexWrap: "wrap",
          gap: "15px"
        }}>
          <h1 style={{ margin: 0 }}>Website Blocklist Settings</h1>
          <button
            onClick={() => navigate("/")}
            style={{
              padding: "10px 20px",
              border: "none",
              borderRadius: "5px",
              cursor: "pointer"
            }}
          >
            Back to Dashboard
          </button>
        </div>

        <p style={{marginBottom: "30px" }}>
          Add websites you want to block during your focus sessions. 
          Enter just the domain (e.g., youtube.com).
        </p>

        {syncing && (
          <div style={{
            padding: "10px",
            borderRadius: "5px",
            marginBottom: "20px",
            textAlign: "center"
          }}>
            Syncing with extension...
          </div>
        )}

        {error && (
          <div style={{
            padding: "12px",
            borderRadius: "5px",
            marginBottom: "20px",
          }}>
             {error}
          </div>
        )}

        <form onSubmit={addSite} style={{ marginBottom: "40px" }}>
          <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
            <input
              type="text"
              value={newSite}
              onChange={handleInputChange}
              placeholder="e.g., youtube.com"
              style={{
                flex: 1,
                minWidth: "250px",
                padding: "12px",
                fontSize: "16px",
                borderRadius: "5px",
                outline: "none"
              }}
            />
            <button
              type="submit"
              disabled={loading || !newSite.trim()}
              style={{
                padding: "12px 30px",
                fontSize: "16px",
                backgroundColor: loading || !newSite.trim() ? "#ccc" : "#28a745",
                color: "white",
                border: "none",
                borderRadius: "5px",
                cursor: loading || !newSite.trim() ? "not-allowed" : "pointer"
              }}
            >
              {loading ? "Adding..." : "Add Site"}
            </button>
          </div>
          <p style={{ 
            fontSize: "14px", 
            marginTop: "10px",
            marginBottom: 0 
          }}>
          </p>
        </form>

        <div>
          <h2 style={{ marginBottom: "20px" }}>
            Blocked Sites ({blockedSites.length})
          </h2>

          {loading && blockedSites.length === 0 ? (
            <p style={{ textAlign: "center", padding: "40px" }}>
              Loading...
            </p>
          ) : blockedSites.length === 0 ? (
            <div style={{
              textAlign: "center",
              padding: "40px",
              borderRadius: "5px",
            }}>
              <p style={{fontSize: "18px", margin: 0 }}>
                 No sites blocked yet. Add one above to get started!
              </p>
            </div>
          ) : (
            <ul style={{ listStyle: "none", padding: 0 }}>
              {blockedSites.map((site, index) => (
                <li
                  key={index}
                  style={{
                    padding: "15px",
                    marginBottom: "10px",
                    borderRadius: "5px",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    flexWrap: "wrap",
                    gap: "10px"
                  }}
                >
                  <span style={{ 
                    fontSize: "16px", 
                    fontWeight: "500",
                    wordBreak: "break-all"
                  }}>
                     {site}
                  </span>
                  <button
                    onClick={() => removeSite(site)}
                    style={{
                      padding: "8px 20px",
                      border: "none",
                      borderRadius: "5px",
                      cursor: "pointer",
                      fontSize: "14px"
                    }}
                  >
                    Remove
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}