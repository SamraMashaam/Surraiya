import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import BlockPage from "./pages/BlockPage";
import SettingsPage from "./pages/SettingsPage";

function App() {
  return (
    <Router>
      <div className="App">
        <h1>This is the dashboard for now</h1>
        <Routes>
          <Route path="/focus" element={<BlockPage />} />
          <Route path="/" element={<SettingsPage />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
